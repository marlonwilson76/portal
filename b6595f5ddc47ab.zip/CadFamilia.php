<?php

class CadFamilia extends TRecord
{
    const TABLENAME  = 'cad_familia';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('dt_cadastro');
        parent::addAttribute('nome_resp');
        parent::addAttribute('cpf_resp');
        parent::addAttribute('tipo_residencia');
        parent::addAttribute('renda_familia');
        parent::addAttribute('programas_assist');
        parent::addAttribute('local_domicilio');
        parent::addAttribute('abast_agua');
        parent::addAttribute('esgoto');
        parent::addAttribute('lixo');
        parent::addAttribute('tipo_familia');
        parent::addAttribute('povo_tribo');
        parent::addAttribute('qt_pessoas');
            
    }

    /**
     * Method getClientes
     */
    public function getClientes()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cad_familia_id', '=', $this->id));
        return Cliente::getObjects( $criteria );
    }
    /**
     * Method getVinculoFamiliars
     */
    public function getVinculoFamiliars()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('cad_familia_id', '=', $this->id));
        return VinculoFamiliar::getObjects( $criteria );
    }

    public function set_cliente_cad_familia_to_string($cliente_cad_familia_to_string)
    {
        if(is_array($cliente_cad_familia_to_string))
        {
            $values = CadFamilia::where('id', 'in', $cliente_cad_familia_to_string)->getIndexedArray('id', 'id');
            $this->cliente_cad_familia_to_string = implode(', ', $values);
        }
        else
        {
            $this->cliente_cad_familia_to_string = $cliente_cad_familia_to_string;
        }

        $this->vdata['cliente_cad_familia_to_string'] = $this->cliente_cad_familia_to_string;
    }

    public function get_cliente_cad_familia_to_string()
    {
        if(!empty($this->cliente_cad_familia_to_string))
        {
            return $this->cliente_cad_familia_to_string;
        }
    
        $values = Cliente::where('cad_familia_id', '=', $this->id)->getIndexedArray('cad_familia_id','{cad_familia->id}');
        return implode(', ', $values);
    }

    public function set_vinculo_familiar_cad_familia_to_string($vinculo_familiar_cad_familia_to_string)
    {
        if(is_array($vinculo_familiar_cad_familia_to_string))
        {
            $values = CadFamilia::where('id', 'in', $vinculo_familiar_cad_familia_to_string)->getIndexedArray('id', 'id');
            $this->vinculo_familiar_cad_familia_to_string = implode(', ', $values);
        }
        else
        {
            $this->vinculo_familiar_cad_familia_to_string = $vinculo_familiar_cad_familia_to_string;
        }

        $this->vdata['vinculo_familiar_cad_familia_to_string'] = $this->vinculo_familiar_cad_familia_to_string;
    }

    public function get_vinculo_familiar_cad_familia_to_string()
    {
        if(!empty($this->vinculo_familiar_cad_familia_to_string))
        {
            return $this->vinculo_familiar_cad_familia_to_string;
        }
    
        $values = VinculoFamiliar::where('cad_familia_id', '=', $this->id)->getIndexedArray('cad_familia_id','{cad_familia->id}');
        return implode(', ', $values);
    }

    public function set_vinculo_familiar_cliente_to_string($vinculo_familiar_cliente_to_string)
    {
        if(is_array($vinculo_familiar_cliente_to_string))
        {
            $values = Cliente::where('id', 'in', $vinculo_familiar_cliente_to_string)->getIndexedArray('nome', 'nome');
            $this->vinculo_familiar_cliente_to_string = implode(', ', $values);
        }
        else
        {
            $this->vinculo_familiar_cliente_to_string = $vinculo_familiar_cliente_to_string;
        }

        $this->vdata['vinculo_familiar_cliente_to_string'] = $this->vinculo_familiar_cliente_to_string;
    }

    public function get_vinculo_familiar_cliente_to_string()
    {
        if(!empty($this->vinculo_familiar_cliente_to_string))
        {
            return $this->vinculo_familiar_cliente_to_string;
        }
    
        $values = VinculoFamiliar::where('cad_familia_id', '=', $this->id)->getIndexedArray('cliente_id','{cliente->nome}');
        return implode(', ', $values);
    }

    
}

