<?php

class TemplateEmail extends TRecord
{
    const TABLENAME  = 'template_email';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nome');
        parent::addAttribute('titulo');
        parent::addAttribute('conteudo');
            
    }

    
}

