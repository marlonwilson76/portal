<?php

class VinculoFamiliar extends TRecord
{
    const TABLENAME  = 'vinculo_familiar';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $cad_familia;
    private $cliente;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('cad_familia_id');
        parent::addAttribute('cliente_id');
            
    }

    /**
     * Method set_cad_familia
     * Sample of usage: $var->cad_familia = $object;
     * @param $object Instance of CadFamilia
     */
    public function set_cad_familia(CadFamilia $object)
    {
        $this->cad_familia = $object;
        $this->cad_familia_id = $object->id;
    }

    /**
     * Method get_cad_familia
     * Sample of usage: $var->cad_familia->attribute;
     * @returns CadFamilia instance
     */
    public function get_cad_familia()
    {
    
        // loads the associated object
        if (empty($this->cad_familia))
            $this->cad_familia = new CadFamilia($this->cad_familia_id);
    
        // returns the associated object
        return $this->cad_familia;
    }
    /**
     * Method set_cliente
     * Sample of usage: $var->cliente = $object;
     * @param $object Instance of Cliente
     */
    public function set_cliente(Cliente $object)
    {
        $this->cliente = $object;
        $this->cliente_id = $object->id;
    }

    /**
     * Method get_cliente
     * Sample of usage: $var->cliente->attribute;
     * @returns Cliente instance
     */
    public function get_cliente()
    {
    
        // loads the associated object
        if (empty($this->cliente))
            $this->cliente = new Cliente($this->cliente_id);
    
        // returns the associated object
        return $this->cliente;
    }

    
}

